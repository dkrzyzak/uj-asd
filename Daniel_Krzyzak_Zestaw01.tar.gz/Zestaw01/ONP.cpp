#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main(int argc, char const *argv[]) {
    string infix;
    cout << "Podaj wyrażenie: ";
    getline(cin, infix); //getline, bo używając samego cin spacja jest znakiem terminującym

    // infix = "( ( 3 + 4 ) * ( 5 / 6 ) )";
    // infix = "((3+4)*(5/6))";
    // infix = "( 11 + ( ( ( ( 1 + 2 ) * ( 4 - 3 ) ) + ( 4 / 2 ) ) * ( 8 - 6 ) ) )";

    string postfix;
    stack<char> onpStack;

    for(string::size_type i = 0; i < infix.size(); i++) {
        switch (infix[i]) {
            // nawias otwierający wrzucamy na stos
            case '(':
                onpStack.push(infix[i]);
                break;
            
            // jeśli napotkamy nawias zamykający, to zaczynamy zrzucać operatory ze stosu
            case ')':
                // robimy tak dopoki nie trafimy na nawias otwierajacy
                while(onpStack.top() != '(') {
                    // spacja przed operatorem
                    postfix += ' ';
                    postfix += onpStack.top();
                    onpStack.pop();
                }
                onpStack.pop();
                break;
            
            case '+':
            case '-':
            case '*':
            case '/':
                postfix += ' ';
                onpStack.push(infix[i]);
                break;

            // pomijamy spacje
            case ' ':
                break;

            default:
                // liczby dopisujemy od razu do stringa wyjściowego
                postfix += infix[i];
                break;
        }
        cout << "current character: " << infix[i] << endl;
        cout << "onpStack size: " << onpStack.size() << endl;
        if (onpStack.size() != 0) {
            cout << "onpStack top: " << onpStack.top() << endl;
        }
        cout << "postfix: " << postfix << endl << endl;
    }

    // gdy skończymy iterować po znakach ze stringa wejściowego, to musimy jeszcze zrzucić ze stosu ewentualne pozostałe tam operatory
    while(!onpStack.empty()) {
        if (onpStack.top() != '(') {
            postfix += onpStack.top();
        }
        onpStack.pop();
    }

    cout << "Zapis ONP: " << postfix << endl;

    return 0;
}
