#include <stdlib.h> // srand, rand, atoi
#include <iostream> // cin, cout, endl
#include <time.h> // time

using namespace std;

int generateNumber() {
    return rand() % 1000000;
}

string generateOperation() {
    int n = rand() % 3;

    if (n == 2) {
        return "A " + to_string(generateNumber());
    }

    if (n == 1) {
        return "D";
    }

    return "S";
}

int main(int argc, char const *argv[]) {
    int commandsCount = atoi(argv[1]);

    if (commandsCount > 10e6 || commandsCount < 1) {
        cout << "Zła liczba argumentow" << endl;
        return 1;
    }

    srand(time(NULL));
    
    for (int i = 0; i < commandsCount; i++) {
        cout << generateOperation() << endl;
    }
    
    return 0;
}
